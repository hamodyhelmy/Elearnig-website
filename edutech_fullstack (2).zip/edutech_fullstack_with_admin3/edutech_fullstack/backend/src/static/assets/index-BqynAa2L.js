// This is a compiled file, checking for API URLs

